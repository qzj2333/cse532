CSE 532 Spring 2020 Lab 2
Nicole Wang (l.wang12@wustl.edu), Lin Li(lilin1@wustl.edu)

==================================== Lab 2 =================================================
---------- Part 1 -----------
Overview:
1. Play class:
1). Container structor for a line in any character file, which stores the line order, character name and text.
2). Private member variables: a mutex lock, condition variable, line counter of current fragment, fragment counter, number of characters on stage counter, a string vector for all scene names of current script, a string vector iterator for scene names vector.
3). Public Play constructor: takes in a reference to string vector which should be the names of scenes passed in, and initialize line counter as 1, scene_fragment_counter as 1, on_stage should default by 0, pass input parameter to private string vector scene names, and set public string current character as empty("").
4). Public recite() method:  takes in container vector iterator and a reference to scene_fragment_number: Basically we follow the steps given in the lab2 instruction
	a). make a unique_lock to avoid race condition;
	b). Follow the steps given in recite method, and modify the implementation when scene_fragment_counter == scene_fragment_number && line_counter == iter->order, so that to change the character name printed when the passed character is different than current character, and then print out text and increment line_counter. Then, follow the steps given in instruction of lab2 to stress the error when counter is greater than order number.
	c). Last, make sure to unlock and notify all, increment iteration and return.
5). Public enter() method: takes in a shared pointer Fragment which we created for fragment of scene structor in common.h
	a).  Basically, this method is to handle the enter of the character for the fragment,
	b).	If fragment number is different, either it enters failed when smaller than counter or wait on a condition until they are same when bigger than counter
	c). Otherwise, it will print out who enters and increment on_stage, unlock and return success with no error code.
6). Public exit() method: takes in a shared pointer Fragment which we created for fragment of scene structor in common.h
	a). Make a mutex lock and follow 3 conditions on checking the on_stage variable
	b). If on_stage is bigger than 1, we decremtn on_stage and print who exits and return success
	c). If on_stage is smaller than 1, we will return exit fail.
	d). Otherwise, on_stage is exactly 1, we will decrement on_stage, print who exits, increment fragment counter to indicate end of fragment, and make current character string as default empty, and make line_counter as 1 to switch to new fragment file. Also check for iterator member variable to make sure all lines in container has printed out. Notify all and return success.

2. Director Class: (HS/HA pattern design)
1). Private member variables: a string vector to store scene names, a vector with shared pointer for fragement to store all fragments, a vector with shared pointer for players to store all players
2). Public play accessible variable to indicate the play of the current script file.
3). Public Director constructor: takes in string name of the script file, a int min_num_players to indicate min number of players/threads created in the program if flag == false, a bool flag.
	a). Pass the name of scene to input file stream and read from it. If it is open and line is not empty, we will check the first string is or is not [Scene], if yes, we push its scene name to scene name member variable, and we set our bool last_is_scene to indicate previous read line is a scene. 
	b). If we did not find a space in this read line from input file stream, we will open the config file read from this line and read each non-empty line, pass the information of character name, config file name and fragment number into our created Fragment structor, and push back the Fragment in the corresponding member variable.
	c). Then, keep track of max config lines, in compare of max_config_lines and current config lines and previous config lines, update last_config_line to current config lines and reset current config line. 
	d). If previous line in partial config file is not scene, we will push a empty string to member variable, and set it as false, increment fragement number. 
	e). Otherwise, if the file cannot open, just print out error message.
	f). Now we set our public member variable play as a new play of the scene. 
	g). Then we check the flag inputted by the user. If true, we use the minimum number of players stated by the users. Otherwise, just use exactly how many characters in the play.
	h). For each player, set up player shared pointer and run player constructor.
	i). If we cannot open partial scene file, we will throw exception.
4). Public cue() method:
	a). for each fragment in the fragments variables, we will equally assign it with different players and ask it to enter. 
	b). If the entered player number is smaller than actual players should enter, it will iterate through players, and set extra players as end.

3. Player class:
1). Private member variables: a Play variable to keep track where this player belong to, corresponding thread of current player, container vector to store all the contents of a fragment in the working queue, a working queue contains shared pointer of all fragments for current thread, a mutex lock and a condition variable.
2). Public boolean variable end to indicate the end of the fragment.
3). Public Player construction: takes in a play variable:
	a). initialize currPlay member variable with input parameter play object, set end as default false.
	b). construct thread and call member function prepare().
	c). Move the thread
4). Public Player destructor: notify all thread the end of play and if the thread is ready to join, then join them.
5). Public prepare() method: 
	a). Basically, it will get one fragment a time from working queue, and call read the fragment by calling the member function read(fragement).
	b). If we have not finished all the fragment in the queue, the program should make lock and ask the thread to wait until all fragments have been read and proceeded or the scene is finished for 400ms.
	c). If there is still fragment in the fragment_queue, it shoud pop the fragment, unlock the mutex, notify all and read the fragment. At this point, we should also check whether the read() is finished. If it is, notify all and break.
	d). Otherwise, unlock, notify and return.
6). Public read() method: takes in a reference to the fragment that has just popped from the queue:
	a). first thing we need to do is to clean the content vector, and then read lines from each fragment filename, we will skip all empty lines.
	b). If we did not find a white space in the line, it will be a badly formatted line, we will print the error message but continue to read. 
	c). Otherwise, read the valid lines, cast the string line number to int. Pass the line information and text and character name into the container. Push the container into content which the container vector. 
	d). If we cannot extract two elements from the line, we will print the error message to indicate bad line. 
	e). Then, after all lines have read, we will call play to enter, and act method in the player class to ask the player to recite their parts, and finally ask play to exit. 
	f). Of course, we will print a error message if the fragment file cannot open.
7). Public act() method: takes in a reference to the fragment that has just popped from the queue:
	a). initialize the content iterator for it to be passed into recite() method in Play class
	b). If the content is not empty, we will call  the recite() method with input parameters, content iterator and the fragment number of the input fragment popped.
8). Public enter() method: takes in a reference to the fragment that has just popped from the queue: this method is to add given fragment to the working queue with locking scheme. 

4. Main function in lab2.cpp:
1). If the user only inputs the partial script file, we will try to construct a director with the file name, and call its cue() method. If we failed the try in any sense, we will print all error message we get with a error code.
2). If the user inputs also the minimum number of players, we will try to construct a director with file name and as well as the minimum number of players inputted, and call cue(). If failed, we print error message and return an error code. If we failed to extract the minimum number of players, we will print usage message and indicate input not correct.
3). This part is for extra credit, which the input with "-override" indicatior, we will try to make Director constructor with file name, minimum player and the flag as true and call cue(). Otherwise, print error message and return error code. If input is not right, return error code. 
4). For other circumstances different from above 3 inputs, we will print the usage message and return error code.
5). Finally, return success.

Wrapper Facedes:
1. Classes are cohensive:
class Director
{
public:
	Play* play;	// the play of current script file
	Director(string name, int min_num_players = 0, bool flag = false);
	void cue();
};

class Player {
public:
	bool end;
	Player(Play& p);
	~Player();
	void prepare();	
	void read(shared_ptr<Fragment>& f);
	void act(shared_ptr<Fragment>& f);
	void enter(shared_ptr<Fragment>& fragment);
};

class Play
{
public:
	string currCharacter;
	Play(vector<string>& n);
	void recite(vector<container>::iterator& iter, unsigned int& scene_fragment_number);
	int enter(shared_ptr<Fragment> f);
	int exit(shared_ptr<Fragment> f);
};
In our main method, we called Director constructor, then when preparing, we call Play constructor and Player constructor with input play object. Since we used Play object in player class, we will include Play class in Player class and have a neat heirachy.

2. We have made a Fragment object structor in common.h which stores all our common variables. This Fragment structor has been used in many places to indicate the current processing fragment contents. In Play class, we used it in our enter() and exit() method to compare them with the scene fragment counter and also check the names of characters to indicate their enters and exits. In Player class, fragment object is crucial as it made up of our working queue. We will read fragment by fragment as long as it is popped. See details in description of Player class in the overview section. Also in Director class, this is where we construct the Fragment and store it in our working queue for later usage. 


Insights, Observations & Questions:
1. Change arg in Play::enter & exit: from unsigned int (frag num) to Fragment& --> to get character name.
2. In extra credit part 2, where we need to implement "-override", if we use less than 4 minimum players in our input command line, we will encounter a crash in the program. Since the number of players in last fragment are 4, if we only started with less than 4 (eg. 3), the other 3 players will infinitely wait for the forth player to speak when it is his or her turn, thus, causing the program to crash.


---------- Part 2 ------------
Unpacking Instructions:
1. Log in into remote desktop and download the Lab2_Full zip file in the email.
2. Open the downloaded and extracted Lab2_Full directory and find lab2.zip, and right click on the zip file, select: 7-zip -> Extract Here.
2. Open the terminal and log in to remote linux lab, by using "ssh [username]@linuxlab009.engr.wustl.edu" and inputting your password for wustl key.
3. Direct to \lab2_Full\lab2\ directory and make sure you can see the "Makefile", then followed either by 3a) or 3b) below to enable -std=c++17 worked.
a). Type in "module add gcc-8.3.0" in command line.
b). Open ~/.bash_profile and ~/.bashrc files, add line "module add gcc-8.3.0", save and exit.
4. Now, type "make", you should see "g++ -Wall -std=c++17 -pthread -DTEMPLATE_HEADERS_INCLUDE_SOURCE -o lab2 lab2.cpp  Play.cpp  Player.cpp Director.cpp" formed automatically. 
5. You can type the following commands to test the program:
a). ./lab2 partial_hamlet_act_ii_script.txt
b). ./lab2 partial_hamlet_act_ii_script.txt [any number eg. 9]
c). ./lab2 partial_hamlet_act_ii_script.txt [any number eg. 9] -override (for extra credit part)



---------- Part 3 ------------
Evaluation:
1. Well Formed content:
After make, 
Command Line 1: ./lab2 partial_hamlet_act_ii_script.txt
Command Line 2: ./lab2 partial_hamlet_act_ii_script.txt 5

Files involved in: 
partial_hamlet_act_ii_script.txt
Polonius_hamlet_ii_1a.txt and Reynaldo_hamlet_ii_1a.txt in hamlet_ii_1a_config.txt, Polonius_hamlet_ii_1b.txt and Ophelia_hamlet_ii_1b.txt in hamlet_ii_1b_config.txt, 
and King_hamlet_ii_2a.txt and Queen_hamlet_ii_2a.txt and Rosencrantz_hamlet_ii_2a.txt 
and Guildenstern_hamlet_ii_2a.txt in hamlet_ii_2a_config.txt

Changes made: None

Output: 
Hamlet Prince of Denmark ACT II Scene I A room in Polonius house by William Shakespeare
[Enter Reynaldo.]
[Enter Polonius.]

Polonius.
Give him this money and these notes, Reynaldo.

Reynaldo.
I will, my lord.

Polonius.
You shall do marvellous wisely, good Reynaldo,
Before You visit him, to make inquiry
Of his behaviour.

Reynaldo.
My lord, I did intend it.

Polonius.
Marry, well said; very well said. Look you, sir,
Enquire me first what Danskers are in Paris;
And how, and who, what means, and where they keep,
What company, at what expense; and finding,
By this encompassment and drift of question,
That they do know my son, come you more nearer
Than your particular demands will touch it:
Take you, as 'twere, some distant knowledge of him;
As thus, 'I know his father and his friends,
And in part hi;m;--do you mark this, Reynaldo?

Reynaldo.
Ay, very well, my lord.

Polonius.
'And in part him;--but,' you may say, 'not well:
But if't be he I mean, he's very wild;
Addicted so and so;' and there put on him
What forgeries you please; marry, none so rank
As may dishonour him; take heed of that;
But, sir, such wanton, wild, and usual slips
As are companions noted and most known
To youth and liberty.

Reynaldo.
As gaming, my lord.

Polonius.
Ay, or drinking, fencing, swearing, quarrelling,
Drabbing:--you may go so far.

Reynaldo.
My lord, that would dishonour him.

Polonius.
Faith, no; as you may season it in the charge.
You must not put another scandal on him,
That he is open to incontinency;
That's not my meaning: but breathe his faults so quaintly
That they may seem the taints of liberty;
The flash and outbreak of a fiery mind;
A savageness in unreclaimed blood,
Of general assault.

Reynaldo.
But, my good lord,--

Polonius.
Wherefore should you do this?

Reynaldo.
Ay, my lord,
I would know that.

Polonius.
Marry, sir, here's my drift;
And I believe it is a fetch of warrant:
You laying these slight sullies on my son
As 'twere a thing a little soil'd i' the working,
Mark you,
Your party in converse, him you would sound,
Having ever seen in the prenominate crimes
The youth you breathe of guilty, be assur'd
He closes with you in this consequence;
'Good sir,' or so; or 'friend,' or 'gentleman'--
According to the phrase or the addition
Of man and country.

Reynaldo.
Very good, my lord.

Polonius.
And then, sir, does he this,--he does--What was I about to say?--
By the mass, I was about to say something:--Where did I leave?

Reynaldo.
At 'closes in the consequence,' at 'friend or so,' and
gentleman.'

Polonius.
At--closes in the consequence'--ay, marry!
He closes with you thus:--'I know the gentleman;
I saw him yesterday, or t'other day,
Or then, or then; with such, or such; and, as you say,
There was he gaming; there o'ertook in's rouse;
There falling out at tennis': or perchance,
'I saw him enter such a house of sale,'--
Videlicet, a brothel,--or so forth.--
See you now;
Your bait of falsehood takes this carp of truth:
And thus do we of wisdom and of reach,
With windlaces, and with assays of bias,
By indirections find directions out:
So, by my former lecture and advice,
Shall you my son. You have me, have you not?

Reynaldo.
My lord, I have.

Polonius.
God b' wi' you, fare you well.

Reynaldo.
Good my lord!

Polonius.
Observe his inclination in yourself.

Reynaldo.
I shall, my lord.

Polonius.
And let him ply his music.

Reynaldo.
Well, my lord.

Polonius.
Farewell!
[Exit Polonius.]
[Exit Reynaldo.]
[Enter Ophelia.]
[Enter Polonius.]

Polonius.
How now, Ophelia! what's the matter?

Ophelia.
Alas, my lord, I have been so affrighted!

Polonius.
With what, i' the name of God?

Ophelia.
My lord, as I was sewing in my chamber,
Lord Hamlet,--with his doublet all unbrac'd;
No hat upon his head; his stockings foul'd,
Ungart'red, and down-gyved to his ankle;
Pale as his shirt; his knees knocking each other;
And with a look so piteous in purport
As if he had been loosed out of hell
To speak of horrors,--he comes before me.

Polonius.
Mad for thy love?

Ophelia.
My lord, I do not know;
But truly I do fear it.

Polonius.
What said he?

Ophelia.
He took me by the wrist, and held me hard;
Then goes he to the length of all his arm;
And with his other hand thus o'er his brow,
He falls to such perusal of my face
As he would draw it. Long stay'd he so;
At last,--a little shaking of mine arm,
And thrice his head thus waving up and down,--
He rais'd a sigh so piteous and profound
As it did seem to shatter all his bulk
And end his being: that done, he lets me go:
And, with his head over his shoulder turn'd
He seem'd to find his way without his eyes;
For out o' doors he went without their help,
And to the last bended their light on me.

Polonius.
Come, go with me: I will go seek the king.
This is the very ecstasy of love;
Whose violent property fordoes itself,
And leads the will to desperate undertakings,
As oft as any passion under heaven
That does afflict our natures. I am sorry,--
What, have you given him any hard words of late?

Ophelia.
No, my good lord; but, as you did command,
I did repel his letters and denied
His access to me.
[Exit Ophelia.]

Polonius.
That hath made him mad.
I am sorry that with better heed and judgment
I had not quoted him: I fear'd he did but trifle,
And meant to wreck thee; but beshrew my jealousy!
It seems it as proper to our age
To cast beyond ourselves in our opinions
As it is common for the younger sort
To lack discretion. Come, go we to the king:
This must be known; which, being kept close, might move
More grief to hide than hate to utter love.
[Exit Polonius.]
Hamlet Prince of Denmark ACT II Scene II A room in the Castle by William Shakespeare

[Enter Guildenstern.]
[Enter King.]

King.
Welcome, dear Rosencrantz and Guildenstern!
[Enter Rosencrantz.]
[Enter Queen.]
Moreover that we much did long to see you,
The need we have to use you did provoke
Our hasty sending. Something have you heard
Of Hamlet's transformation; so I call it,
Since nor the exterior nor the inward man
Resembles that it was. What it should be,
More than his father's death, that thus hath put him
So much from the understanding of himself,
I cannot dream of: I entreat you both
That, being of so young days brought up with him,
And since so neighbour'd to his youth and humour,
That you vouchsafe your rest here in our court
Some little time: so by your companies
To draw him on to pleasures, and to gather,
So much as from occasion you may glean,
Whether aught, to us unknown, afflicts him thus,
That, open'd, lies within our remedy.

Queen.
Good gentlemen, he hath much talk'd of you,
And sure I am two men there are not living
To whom he more adheres. If it will please you
To show us so much gentry and good-will
As to expend your time with us awhile,
For the supply and profit of our hope,
Your visitation shall receive such thanks
As fits a king's remembrance.

Rosencrantz.
Both your majesties
Might, by the sovereign power you have of us,
Put your dread pleasures more into command
Than to entreaty.

Guildenstern.
We both obey,
And here give up ourselves, in the full bent,
To lay our service freely at your feet,
To be commanded.
[Exit Rosencrantz.]

King.
Thanks, Rosencrantz and gentle Guildenstern.
[Exit King.]

Queen.
Thanks, Guildenstern and gentle Rosencrantz:
And I beseech you instantly to visit
My too-much-changed son.--Go, some of you,
And bring these gentlemen where Hamlet is.

Guildenstern.
Heavens make our presence and our practices
Pleasant and helpful to him!
[Exit Guildenstern.]

Queen.
Ay, amen!
[Exit Queen.]

Return: success

2. Bad User Input: 
1).
Command Line 1: ./lab2 
Output: 
usage: lab2.exe <configuration_file_name> || lab2.exe <configuration_file_name> <min_num_players> || lab2.exe <configuration_file_name> <num_players> -override
Return: inputNotCorrect

2).
Command Line 2: ./lab2 fs
Output:
Can not open script file
Return: FileNotExist

3).
Command Line 3: ./lab2 partial_hamlet_act_ii_script.txt qw
Output:
usage: lab2.exe <configuration_file_name> || lab2.exe <configuration_file_name> <min_num_players> || lab2.exe <configuration_file_name> <num_players> -override
Return: inputNotCorrect


3. Badly format part file:
1). 
Command Line 1: ./lab2 partial_hamlet_act_ii_script.txt
Command Line 2: ./lab2 partial_hamlet_act_ii_script.txt 5

Files involved in: 
partial_hamlet_act_ii_script.txt
Polonius_hamlet_ii_1a.txt and Reynaldo_hamlet_ii_1a.txt in hamlet_ii_1a_config.txt, Polonius_hamlet_ii_1b.txt and Ophelia_hamlet_ii_1b.txt in hamlet_ii_1b_config.txt, 
and King_hamlet_ii_2a.txt and Queen_hamlet_ii_2a.txt and Rosencrantz_hamlet_ii_2a.txt 
and Guildenstern_hamlet_ii_2a.txt in hamlet_ii_2a_config.txt

Changes made: In file Polonius_hamlet_ii_1a.txt
45 As 'twere a thing a little soil'd i' the working, 
-1 
46 Mark you,

Output: should be same as well format output, we will skip this badly format line, but we have a printed line shown as "badly formatted line read"
Return: success



2). 
Command Line 1: ./lab2 partial_hamlet_act_ii_script.txt
Command Line 2: ./lab2 partial_hamlet_act_ii_script.txt 5

Files involved in: 
partial_hamlet_act_ii_script.txt
Polonius_hamlet_ii_1a.txt and Reynaldo_hamlet_ii_1a.txt in hamlet_ii_1a_config.txt, Polonius_hamlet_ii_1b.txt and Ophelia_hamlet_ii_1b.txt in hamlet_ii_1b_config.txt, 
and King_hamlet_ii_2a.txt and Queen_hamlet_ii_2a.txt and Rosencrantz_hamlet_ii_2a.txt 
and Guildenstern_hamlet_ii_2a.txt in hamlet_ii_2a_config.txt

Changes made: In file Polonius_hamlet_ii_1a.txt
45 As 'twere a thing a little soil'd i' the working, 
-1 Bad Line
46 Mark you,

Output: should be same as well format output, we will skip this badly format line, but we have a printed line shown as "bad line number read"
Return: success

3). 
Command Line 1: ./lab2 partial_hamlet_act_ii_script.txt
Command Line 2: ./lab2 partial_hamlet_act_ii_script.txt 5

Files involved in: 
partial_hamlet_act_ii_script.txt
Polonius_hamlet_ii_1a.txt and Reynaldo_hamlet_ii_1a.txt in hamlet_ii_1a_config.txt, Polonius_hamlet_ii_1b.txt and Ophelia_hamlet_ii_1b.txt in hamlet_ii_1b_config.txt, 
and King_hamlet_ii_2a.txt and Queen_hamlet_ii_2a.txt and Rosencrantz_hamlet_ii_2a.txt 
and Guildenstern_hamlet_ii_2a.txt in hamlet_ii_2a_config.txt

Changes made: In file Polonius_hamlet_ii_1a.txt
45 As 'twere a thing a little soil'd i' the working, 
Bad Line
46 Mark you,

Output: should be same as well format output, we will skip this badly format line, but we have a printed line shown as "bad line number read"
Return: success

4. Badly formated input partial script file
Command Line 1: ./lab2 partial_hamlet_act_ii_script.txt
Command Line 2: ./lab2 partial_hamlet_act_ii_script.txt 5

Files involved in: 
partial_hamlet_act_ii_script.txt
Polonius_hamlet_ii_1a.txt and Reynaldo_hamlet_ii_1a.txt in hamlet_ii_1a_config.txt, Polonius_hamlet_ii_1b.txt and Ophelia_hamlet_ii_1b.txt in hamlet_ii_1b_config.txt, 
and King_hamlet_ii_2a.txt and Queen_hamlet_ii_2a.txt and Rosencrantz_hamlet_ii_2a.txt 
and Guildenstern_hamlet_ii_2a.txt in hamlet_ii_2a_config.txt

1).
Changes made: in partial_hamlet_act_ii_script.txt
[scene] Hamlet Prince of Denmark ACT II Scene I A room in Polonius house by William Shakespeare
hhh
hamlet_ii_1a_config.txt
hamlet_ii_1b_config.txt
[scene] Hamlet Prince of Denmark ACT II Scene II A room in the Castle by William Shakespeare
hamlet_ii_2a_config.txt

Output: hould be same as well format output, we will skip this badly format line, but we have a printed line shown as "Can not open config file hhh"
Return: success

2).
Changes made: in partial_hamlet_act_ii_script.txt
[scene] Hamlet Prince of Denmark ACT II Scene I A room in Polonius house by William Shakespeare
[Sc] fff
hamlet_ii_1a_config.txt
hamlet_ii_1b_config.txt
[scene] Hamlet Prince of Denmark ACT II Scene II A room in the Castle by William Shakespeare
hamlet_ii_2a_config.txt

Output: hould be same as well format output, we will skip this badly format line
Return: success

5. Badly formatted fragment config file
Command Line 1: lab2.exe partial_hamlet_act_ii_script.txt
Command Line 2: lab2.exe partial_hamlet_act_ii_script.txt 5

Files involved in: 
partial_hamlet_act_ii_script.txt
Polonius_hamlet_ii_1a.txt and Reynaldo_hamlet_ii_1a.txt in hamlet_ii_1a_config.txt, Polonius_hamlet_ii_1b.txt and Ophelia_hamlet_ii_1b.txt in hamlet_ii_1b_config.txt, 
and King_hamlet_ii_2a.txt and Queen_hamlet_ii_2a.txt and Rosencrantz_hamlet_ii_2a.txt 
and Guildenstern_hamlet_ii_2a.txt in hamlet_ii_2a_config.txt

Changes made: in hamlet_ii_1a_config.txt
Polonius Polonius_hamlet_ii_1a.txt
ccc (or ccc.txt)
Reynaldo Reynaldo_hamlet_ii_1a.txt

Output: hould be same as well format output, we will skip this badly format line
Return: success


=========================== Lab2 Extra Credit ===========================
------------- Part 1 (in lab2Extra folder) ------------
Approach to extra credit part:
1. Arguments: 2 arguments
1). execution file name (lab2Extra.exe)
2). the name of the scene fragment file (hamlet_act_ii_scene_1.txt)

2. Main Function: check for right number of arguments whether it is 2
1). If argument number is 2, 
	a). We will first create our partial play text file name by parsing the name of the input file name. 
	b). Then, we will create the name of config file by ignoring the scene and act words in the input file name, and create a token with the name of the play and part of the act.
	c). We will both open the input file and output partial script, make a map to store the character information of both character name as the key and the lines that belong to this character as the value
	d). If we read an empty line, we will indicate it as change of the character and make indication of that.
	e). If we read a title, we will output it to our partial script file, and set readTitle as false to indicate the start of the current fragment.
	f). Otherwise, if we read line starts with "[Enter]", we will continue. 
	g). If we read line starts with "[Exit]", we will set exit indicator to true, and prepare the fragment config file and character part file. To do that, we will pass the character name and character name with ".txt" to the fragment config file. Also, open each created character part file, we will output each lines in the map values belongs to this character. Then, we will close files, clean the map, increment fragment number, 
	h). Otherwise, we will set exit indicator to false to indicate that the play does not change the fragment at this point. If we change the character, we will set changeCharacter to false, until we reach a blank line we will change it back (in step (d)), and we will find the character key in the map and insert its text line into the string vector (value of the map). Otherwise, which means we did not change character, we will continue to push the text line to the character's value in the map.
	i). Close all input and output file, and return success.
	j). If the input or partial script output file cannot be opened, we will print error message to indicate that and return a error code fileDoesNotExist.
2). Otherwise, the argument number is not correct, we will print usage message and return numberArgumentIncorrect code.



Unpacking Instructions:
1. Log in into remote desktop and download the Lab2_Full zip file in the email.
2. Open the downloaded and extracted Lab2_Full directory and find lab2Extra.zip, and right click on the zip file, select: 7-zip -> Extract Here.
2. Open the terminal and log in to remote linux lab, by using "ssh [username]@linuxlab009.engr.wustl.edu" and inputting your password for wustl key.
3. Direct to \lab2_Full\lab2Extra\ directory and make sure you can see the "Makefile", then followed either by 3a) or 3b) below to enable -std=c++17 worked.
a). Type in "module add gcc-8.3.0" in command line.
b). Open ~/.bash_profile and ~/.bashrc files, add line "module add gcc-8.3.0", save and exit.
4. Now, type "make", you should see "g++ -Wall -std=c++17 -pthread -DTEMPLATE_HEADERS_INCLUDE_SOURCE -o lab2Extra lab2Extra.cpp" formed automatically. 
5. You can type the following commands to test the program: ./lab2Extra hamlet_act_ii_scene_1.txt 


Document how you used it in your testing of the assignment
1.
2. Testing:
(1). Command Input: ./lab2Extra hamlet_act_ii_scene_1.txt
Output: 
a). Files: hamlet_ii_1a_config.txt, hamlet_ii_1b_config.txt, Ophelia_hamlet_ii_1b.txt, Polonius_hamlet_ii_1a.txt, Polonius_hamlet_ii_1b.txt, Reynaldo_hamlet_ii_1a.txt, partial_hamlet_act_ii_scene_1_script.txt

b). hamlet_ii_1a_config.txt:
Polonius Polonius_hamlet_ii_1a.txt
Reynaldo Reynaldo_hamlet_ii_1a.txt

c). hamlet_ii_1b_config.txt:
Ophelia Ophelia_hamlet_ii_1b.txt
Polonius Polonius_hamlet_ii_1b.txt

d). Ophelia_hamlet_ii_1b.txt: 
2 Alas, my lord, I have been so affrighted!
4 My lord, as I was sewing in my chamber, 
5 Lord Hamlet,--with his doublet all unbrac'd; 
6 No hat upon his head; his stockings foul'd, 
7 Ungart'red, and down-gyved to his ankle; 
8 Pale as his shirt; his knees knocking each other; 
9 And with a look so piteous in purport 
10 As if he had been loosed out of hell 
11 To speak of horrors,--he comes before me.
13 My lord, I do not know; 
14 But truly I do fear it.
16 He took me by the wrist, and held me hard; 
17 Then goes he to the length of all his arm; 
18 And with his other hand thus o'er his brow, 
19 He falls to such perusal of my face 
20 As he would draw it. Long stay'd he so; 
21 At last,--a little shaking of mine arm, 
22 And thrice his head thus waving up and down,-- 
23 He rais'd a sigh so piteous and profound 
24 As it did seem to shatter all his bulk 
25 And end his being: that done, he lets me go: 
26 And, with his head over his shoulder turn'd 
27 He seem'd to find his way without his eyes; 
28 For out o' doors he went without their help, 
29 And to the last bended their light on me.
37 No, my good lord; but, as you did command, 
38 I did repel his letters and denied 
39 His access to me.

e). Polonius_hamlet_ii_1a.txt:
1 Give him this money and these notes, Reynaldo.
3 You shall do marvellous wisely, good Reynaldo, 
4 Before You visit him, to make inquiry 
5 Of his behaviour.
7 Marry, well said; very well said. Look you, sir, 
8 Enquire me first what Danskers are in Paris; 
9 And how, and who, what means, and where they keep, 
10 What company, at what expense; and finding, 
11 By this encompassment and drift of question, 
12 That they do know my son, come you more nearer 
13 Than your particular demands will touch it: 
14 Take you, as 'twere, some distant knowledge of him; 
15 As thus, 'I know his father and his friends, 
16 And in part hi;m;--do you mark this, Reynaldo?
18 'And in part him;--but,' you may say, 'not well: 
19 But if't be he I mean, he's very wild; 
20 Addicted so and so;' and there put on him 
21 What forgeries you please; marry, none so rank 
22 As may dishonour him; take heed of that; 
23 But, sir, such wanton, wild, and usual slips 
24 As are companions noted and most known 
25 To youth and liberty.
27 Ay, or drinking, fencing, swearing, quarrelling, 
28 Drabbing:--you may go so far.
30 Faith, no; as you may season it in the charge. 
31 You must not put another scandal on him, 
32 That he is open to incontinency; 
33 That's not my meaning: but breathe his faults so quaintly 
34 That they may seem the taints of liberty; 
35 The flash and outbreak of a fiery mind; 
36 A savageness in unreclaimed blood, 
37 Of general assault.
39 Wherefore should you do this?
42 Marry, sir, here's my drift; 
43 And I believe it is a fetch of warrant: 
44 You laying these slight sullies on my son 
45 As 'twere a thing a little soil'd i' the working, 
46 Mark you, 
47 Your party in converse, him you would sound, 
48 Having ever seen in the prenominate crimes 
49 The youth you breathe of guilty, be assur'd 
50 He closes with you in this consequence; 
51 'Good sir,' or so; or 'friend,' or 'gentleman'-- 
52 According to the phrase or the addition 
53 Of man and country.
55 And then, sir, does he this,--he does--What was I about to say?-- 
56 By the mass, I was about to say something:--Where did I leave?
59 At--closes in the consequence'--ay, marry! 
60 He closes with you thus:--'I know the gentleman; 
61 I saw him yesterday, or t'other day, 
62 Or then, or then; with such, or such; and, as you say, 
63 There was he gaming; there o'ertook in's rouse; 
64 There falling out at tennis': or perchance, 
65 'I saw him enter such a house of sale,'-- 
66 Videlicet, a brothel,--or so forth.-- 

f). Polonius_hamlet_ii_1b.txt:
1 How now, Ophelia! what's the matter?
3 With what, i' the name of God?
12 Mad for thy love?
15 What said he?
30 Come, go with me: I will go seek the king. 
31 This is the very ecstasy of love; 
32 Whose violent property fordoes itself, 
33 And leads the will to desperate undertakings, 
34 As oft as any passion under heaven 
35 That does afflict our natures. I am sorry,-- 
36 What, have you given him any hard words of late?
40 That hath made him mad. 
41 I am sorry that with better heed and judgment 
42 I had not quoted him: I fear'd he did but trifle, 
43 And meant to wreck thee; but beshrew my jealousy! 
44 It seems it as proper to our age 
45 To cast beyond ourselves in our opinions 
46 As it is common for the younger sort 
47 To lack discretion. Come, go we to the king: 
48 This must be known; which, being kept close, might move 
49 More grief to hide than hate to utter love. 

g). Reynaldo_hamlet_ii_1a.txt:
2 I will, my lord.
6 My lord, I did intend it.
17 Ay, very well, my lord.
26 As gaming, my lord.
29 My lord, that would dishonour him.
38 But, my good lord,--
40 Ay, my lord, 
41 I would know that.
54 Very good, my lord.
57 At 'closes in the consequence,' at 'friend or so,' and 
58 gentleman.'
74 My lord, I have.
76 Good my lord!
78 I shall, my lord.
80 Well, my lord.

h). partial_hamlet_act_ii_scene_1_script.txt
[scene] Hamlet Prince of Denmark ACT II Scene I A room in Polonius house by William Shakespeare
hamlet_ii_1a.txt
hamlet_ii_1b.txt

Return: success

(2). Command Input: ./lab2Extra
Output: usage: lab2Extra.exe <inputFileName>
Return: numberArgumentIncorrect

(3). Command Input: ./lab2Extra kk
Output: File can not open.
Return: fileDoesNotExist


------------- Part 2 (in lab2 folder) ------------
Approach to the extra credit part:
1. In lab2.cpp main() line 45, we will check the user input as 4, if it is and last argument is same as "-override", 
1). First, get the minimum number players from the input, if we get it, we will try to make Director object with input partial script file name, minimum number of players and the flag as true. Call cue() in director class. If we failed our try, we will print error message and return a error code. (For details, it will be described in the Director class stated in Lab2 section of this readme)
2). Otherwise, we did not get the minimum number players, we will print usage message and return a error code.



Unpacking Instructions:
1. Log in into remote desktop and download the Lab2_Full zip file in the email.
2. Open the downloaded and extracted Lab2_Full directory and find lab2.zip, and right click on the zip file, select: 7-zip -> Extract Here.
2. Open the terminal and log in to remote linux lab, by using "ssh [username]@linuxlab009.engr.wustl.edu" and inputting your password for wustl key.
3. Direct to \lab2_Full\lab2\ directory and make sure you can see the "Makefile", then followed either by 3a) or 3b) below to enable -std=c++17 worked.
a). Type in "module add gcc-8.3.0" in command line.
b). Open ~/.bash_profile and ~/.bashrc files, add line "module add gcc-8.3.0", save and exit.
4. Now, type "make", you should see "g++ -Wall -std=c++17 -pthread -DTEMPLATE_HEADERS_INCLUDE_SOURCE -o lab2 lab2.cpp  Play.cpp  Player.cpp Director.cpp" formed automatically. 
5. You can type the following commands to test the program: ./lab2 partial_hamlet_act_ii_script.txt [any number eg. 9] -override



Document how you used it in your testing of the assignment
1.
2. Testing:
(1). Well formatted command line (with 4 or more minimum number players)
Command Input: ./lab2 partial_hamlet_act_ii_script.txt 4 -override
Output:
Hamlet Prince of Denmark ACT II Scene I A room in Polonius house by William Shakespeare
[Enter Reynaldo.]
[Enter Polonius.]

Polonius.
Give him this money and these notes, Reynaldo.

Reynaldo.
I will, my lord.

Polonius.
You shall do marvellous wisely, good Reynaldo,
Before You visit him, to make inquiry
Of his behaviour.

Reynaldo.
My lord, I did intend it.

Polonius.
Marry, well said; very well said. Look you, sir,
Enquire me first what Danskers are in Paris;
And how, and who, what means, and where they keep,
What company, at what expense; and finding,
By this encompassment and drift of question,
That they do know my son, come you more nearer
Than your particular demands will touch it:
Take you, as 'twere, some distant knowledge of him;
As thus, 'I know his father and his friends,
And in part hi;m;--do you mark this, Reynaldo?

Reynaldo.
Ay, very well, my lord.

Polonius.
'And in part him;--but,' you may say, 'not well:
But if't be he I mean, he's very wild;
Addicted so and so;' and there put on him
What forgeries you please; marry, none so rank
As may dishonour him; take heed of that;
But, sir, such wanton, wild, and usual slips
As are companions noted and most known
To youth and liberty.

Reynaldo.
As gaming, my lord.

Polonius.
Ay, or drinking, fencing, swearing, quarrelling,
Drabbing:--you may go so far.

Reynaldo.
My lord, that would dishonour him.

Polonius.
Faith, no; as you may season it in the charge.
You must not put another scandal on him,
That he is open to incontinency;
That's not my meaning: but breathe his faults so quaintly
That they may seem the taints of liberty;
The flash and outbreak of a fiery mind;
A savageness in unreclaimed blood,
Of general assault.

Reynaldo.
But, my good lord,--

Polonius.
Wherefore should you do this?

Reynaldo.
Ay, my lord,
I would know that.

Polonius.
Marry, sir, here's my drift;
And I believe it is a fetch of warrant:
You laying these slight sullies on my son
As 'twere a thing a little soil'd i' the working,
Mark you,
Your party in converse, him you would sound,
Having ever seen in the prenominate crimes
The youth you breathe of guilty, be assur'd
He closes with you in this consequence;
'Good sir,' or so; or 'friend,' or 'gentleman'--
According to the phrase or the addition
Of man and country.

Reynaldo.
Very good, my lord.

Polonius.
And then, sir, does he this,--he does--What was I about to say?--
By the mass, I was about to say something:--Where did I leave?

Reynaldo.
At 'closes in the consequence,' at 'friend or so,' and
gentleman.'

Polonius.
At--closes in the consequence'--ay, marry!
He closes with you thus:--'I know the gentleman;
I saw him yesterday, or t'other day,
Or then, or then; with such, or such; and, as you say,
There was he gaming; there o'ertook in's rouse;
There falling out at tennis': or perchance,
'I saw him enter such a house of sale,'--
Videlicet, a brothel,--or so forth.--
See you now;
Your bait of falsehood takes this carp of truth:
And thus do we of wisdom and of reach,
With windlaces, and with assays of bias,
By indirections find directions out:
So, by my former lecture and advice,
Shall you my son. You have me, have you not?

Reynaldo.
My lord, I have.

Polonius.
God b' wi' you, fare you well.

Reynaldo.
Good my lord!

Polonius.
Observe his inclination in yourself.

Reynaldo.
I shall, my lord.

Polonius.
And let him ply his music.

Reynaldo.
Well, my lord.
[Exit Reynaldo.]

Polonius.
Farewell!
[Exit Polonius.]
[Enter Ophelia.]
[Enter Polonius.]

Polonius.
How now, Ophelia! what's the matter?

Ophelia.
Alas, my lord, I have been so affrighted!

Polonius.
With what, i' the name of God?

Ophelia.
My lord, as I was sewing in my chamber,
Lord Hamlet,--with his doublet all unbrac'd;
No hat upon his head; his stockings foul'd,
Ungart'red, and down-gyved to his ankle;
Pale as his shirt; his knees knocking each other;
And with a look so piteous in purport
As if he had been loosed out of hell
To speak of horrors,--he comes before me.

Polonius.
Mad for thy love?

Ophelia.
My lord, I do not know;
But truly I do fear it.

Polonius.
What said he?

Ophelia.
He took me by the wrist, and held me hard;
Then goes he to the length of all his arm;
And with his other hand thus o'er his brow,
He falls to such perusal of my face
As he would draw it. Long stay'd he so;
At last,--a little shaking of mine arm,
And thrice his head thus waving up and down,--
He rais'd a sigh so piteous and profound
As it did seem to shatter all his bulk
And end his being: that done, he lets me go:
And, with his head over his shoulder turn'd
He seem'd to find his way without his eyes;
For out o' doors he went without their help,
And to the last bended their light on me.

Polonius.
Come, go with me: I will go seek the king.
This is the very ecstasy of love;
Whose violent property fordoes itself,
And leads the will to desperate undertakings,
As oft as any passion under heaven
That does afflict our natures. I am sorry,--
What, have you given him any hard words of late?

Ophelia.
No, my good lord; but, as you did command,
I did repel his letters and denied
His access to me.

Polonius.
That hath made him mad.
I am sorry that with better heed and judgment
I had not quoted him: I fear'd he did but trifle,
And meant to wreck thee; but beshrew my jealousy!
It seems it as proper to our age
To cast beyond ourselves in our opinions
As it is common for the younger sort
To lack discretion. Come, go we to the king:
This must be known; which, being kept close, might move
More grief to hide than hate to utter love.
[Exit Polonius.]
[Exit Ophelia.]
Hamlet Prince of Denmark ACT II Scene II A room in the Castle by William Shakespeare

[Enter King.]

King.
Welcome, dear Rosencrantz and Guildenstern!
Moreover that we much did long to see you,
The need we have to use you did provoke
Our hasty sending. Something have you heard
Of Hamlet's transformation; so I call it,
Since nor the exterior nor the inward man
Resembles that it was. What it should be,
More than his father's death, that thus hath put him
So much from the understanding of himself,
I cannot dream of: I entreat you both
That, being of so young days brought up with him,
And since so neighbour'd to his youth and humour,
That you vouchsafe your rest here in our court
Some little time: so by your companies
To draw him on to pleasures, and to gather,
So much as from occasion you may glean,
Whether aught, to us unknown, afflicts him thus,
That, open'd, lies within our remedy.
[Enter Queen.]

Queen.
Good gentlemen, he hath much talk'd of you,
[Enter Rosencrantz.]
[Enter Guildenstern.]
And sure I am two men there are not living
To whom he more adheres. If it will please you
To show us so much gentry and good-will
As to expend your time with us awhile,
For the supply and profit of our hope,
Your visitation shall receive such thanks
As fits a king's remembrance.

Rosencrantz.
Both your majesties
Might, by the sovereign power you have of us,
Put your dread pleasures more into command
Than to entreaty.
[Exit Rosencrantz.]

Guildenstern.
We both obey,
And here give up ourselves, in the full bent,
To lay our service freely at your feet,
To be commanded.

King.
Thanks, Rosencrantz and gentle Guildenstern.

Queen.
Thanks, Guildenstern and gentle Rosencrantz:
[Exit King.]
And I beseech you instantly to visit
My too-much-changed son.--Go, some of you,
And bring these gentlemen where Hamlet is.

Guildenstern.
Heavens make our presence and our practices
Pleasant and helpful to him!
[Exit Guildenstern.]

Queen.
Ay, amen!
[Exit Queen.]

Return: success

(2). Badly formatted command line (less than 4 minimum number players)
Command line: ./lab2 partial_hamlet_act_ii_script.txt 3 -override
Output: 
Hamlet Prince of Denmark ACT II Scene I A room in Polonius house by William Shakespeare
[Enter Reynaldo.]
[Enter Polonius.]

Polonius.
Give him this money and these notes, Reynaldo.

Reynaldo.
I will, my lord.

Polonius.
You shall do marvellous wisely, good Reynaldo,
Before You visit him, to make inquiry
Of his behaviour.

Reynaldo.
My lord, I did intend it.

Polonius.
Marry, well said; very well said. Look you, sir,
Enquire me first what Danskers are in Paris;
And how, and who, what means, and where they keep,
What company, at what expense; and finding,
By this encompassment and drift of question,
That they do know my son, come you more nearer
Than your particular demands will touch it:
Take you, as 'twere, some distant knowledge of him;
As thus, 'I know his father and his friends,
And in part hi;m;--do you mark this, Reynaldo?

Reynaldo.
Ay, very well, my lord.

Polonius.
'And in part him;--but,' you may say, 'not well:
But if't be he I mean, he's very wild;
Addicted so and so;' and there put on him
What forgeries you please; marry, none so rank
As may dishonour him; take heed of that;
But, sir, such wanton, wild, and usual slips
As are companions noted and most known
To youth and liberty.

Reynaldo.
As gaming, my lord.

Polonius.
Ay, or drinking, fencing, swearing, quarrelling,
Drabbing:--you may go so far.

Reynaldo.
My lord, that would dishonour him.

Polonius.
Faith, no; as you may season it in the charge.
You must not put another scandal on him,
That he is open to incontinency;
That's not my meaning: but breathe his faults so quaintly
That they may seem the taints of liberty;
The flash and outbreak of a fiery mind;
A savageness in unreclaimed blood,
Of general assault.

Reynaldo.
But, my good lord,--

Polonius.
Wherefore should you do this?

Reynaldo.
Ay, my lord,
I would know that.

Polonius.
Marry, sir, here's my drift;
And I believe it is a fetch of warrant:
You laying these slight sullies on my son
As 'twere a thing a little soil'd i' the working,
Mark you,
Your party in converse, him you would sound,
Having ever seen in the prenominate crimes
The youth you breathe of guilty, be assur'd
He closes with you in this consequence;
'Good sir,' or so; or 'friend,' or 'gentleman'--
According to the phrase or the addition
Of man and country.

Reynaldo.
Very good, my lord.

Polonius.
And then, sir, does he this,--he does--What was I about to say?--
By the mass, I was about to say something:--Where did I leave?

Reynaldo.
At 'closes in the consequence,' at 'friend or so,' and
gentleman.'

Polonius.
At--closes in the consequence'--ay, marry!
He closes with you thus:--'I know the gentleman;
I saw him yesterday, or t'other day,
Or then, or then; with such, or such; and, as you say,
There was he gaming; there o'ertook in's rouse;
There falling out at tennis': or perchance,
'I saw him enter such a house of sale,'--
Videlicet, a brothel,--or so forth.--
See you now;
Your bait of falsehood takes this carp of truth:
And thus do we of wisdom and of reach,
With windlaces, and with assays of bias,
By indirections find directions out:
So, by my former lecture and advice,
Shall you my son. You have me, have you not?

Reynaldo.
My lord, I have.

Polonius.
God b' wi' you, fare you well.

Reynaldo.
Good my lord!

Polonius.
Observe his inclination in yourself.

Reynaldo.
I shall, my lord.

Polonius.
And let him ply his music.

Reynaldo.
Well, my lord.
[Exit Reynaldo.]

Polonius.
Farewell!
[Exit Polonius.]
[Enter Polonius.]

Polonius.
How now, Ophelia! what's the matter?
[Enter Ophelia.]

Ophelia.
Alas, my lord, I have been so affrighted!

Polonius.
With what, i' the name of God?

Ophelia.
My lord, as I was sewing in my chamber,
Lord Hamlet,--with his doublet all unbrac'd;
No hat upon his head; his stockings foul'd,
Ungart'red, and down-gyved to his ankle;
Pale as his shirt; his knees knocking each other;
And with a look so piteous in purport
As if he had been loosed out of hell
To speak of horrors,--he comes before me.

Polonius.
Mad for thy love?

Ophelia.
My lord, I do not know;
But truly I do fear it.

Polonius.
What said he?

Ophelia.
He took me by the wrist, and held me hard;
Then goes he to the length of all his arm;
And with his other hand thus o'er his brow,
He falls to such perusal of my face
As he would draw it. Long stay'd he so;
At last,--a little shaking of mine arm,
And thrice his head thus waving up and down,--
He rais'd a sigh so piteous and profound
As it did seem to shatter all his bulk
And end his being: that done, he lets me go:
And, with his head over his shoulder turn'd
He seem'd to find his way without his eyes;
For out o' doors he went without their help,
And to the last bended their light on me.

Polonius.
Come, go with me: I will go seek the king.
This is the very ecstasy of love;
Whose violent property fordoes itself,
And leads the will to desperate undertakings,
As oft as any passion under heaven
That does afflict our natures. I am sorry,--
What, have you given him any hard words of late?

Ophelia.
No, my good lord; but, as you did command,
I did repel his letters and denied
His access to me.

Polonius.
That hath made him mad.
[Exit Ophelia.]
I am sorry that with better heed and judgment
I had not quoted him: I fear'd he did but trifle,
And meant to wreck thee; but beshrew my jealousy!
It seems it as proper to our age
To cast beyond ourselves in our opinions
As it is common for the younger sort
To lack discretion. Come, go we to the king:
This must be known; which, being kept close, might move
More grief to hide than hate to utter love.
[Exit Polonius.]
Hamlet Prince of Denmark ACT II Scene II A room in the Castle by William Shakespeare

[Enter Queen.]
[Enter Guildenstern.]
[Enter King.]

King.
Welcome, dear Rosencrantz and Guildenstern!
Moreover that we much did long to see you,
The need we have to use you did provoke
Our hasty sending. Something have you heard
Of Hamlet's transformation; so I call it,
Since nor the exterior nor the inward man
Resembles that it was. What it should be,
More than his father's death, that thus hath put him
So much from the understanding of himself,
I cannot dream of: I entreat you both
That, being of so young days brought up with him,
And since so neighbour'd to his youth and humour,
That you vouchsafe your rest here in our court
Some little time: so by your companies
To draw him on to pleasures, and to gather,
So much as from occasion you may glean,
Whether aught, to us unknown, afflicts him thus,
That, open'd, lies within our remedy.

Queen.
Good gentlemen, he hath much talk'd of you,
And sure I am two men there are not living
To whom he more adheres. If it will please you
To show us so much gentry and good-will
As to expend your time with us awhile,
For the supply and profit of our hope,
Your visitation shall receive such thanks
As fits a king's remembrance.
^C (Force quit)

Problem: As I stated in the obeservation, since the players in last fragment, there are 4 players, if we only started with less than 4 (eg. 3), the other 3 players will infinitely wait for the forth player to speak when it is his or her turn, thus, causing the program to crash.













