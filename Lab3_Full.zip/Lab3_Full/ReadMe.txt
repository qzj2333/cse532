How submission file was produced:
> Lab3_Full\
> |- ReadMe.txt
> |- Output\
>    |- Lab3Output1.png
>    |- Lab3Output2.png
>    |- Lab3Output3.png
>    |- Lab3Output4.png
> |- lab3.zip\


Unpack:
Download Lab3_Full.zip, Right click on the zip file, select: 7-zip -> Extract Here
