How submission file was produced:
> Lab1_Full\
> |- ReadMe.txt
> |- Outputs\
>    |- Lab1_Result.PNG
>    |- Lab1Extra_Result_With_SRAMBLE.PNG
>    |- Lab1Extra_Result_Without_SRAMBLE.PNG
>    |- Lab1Extra_OutputFiles_Without_SRAMBLE\
>        |- Rosencrantz.txt
>        |- Guildenstern.txt
>        |- hamlet_ii_2_config.txt
>        |- King.txt
>        |- Queen.txt
>    |- Lab1Extra_OutputFiles_With_SRAMBLE\
>        |- Rosencrantz.txt
>        |- Guildenstern.txt
>        |- hamlet_ii_2_config.txt
>        |- King.txt
>        |- Queen.txt
> |- lab1.zip\
> |- lab1Extra.zip\


Unpack:
Download Lab1_Full.zip, Right click on the zip file, select: 7-zip -> Extract Here
