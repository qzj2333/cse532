CSE 532 Spring 2020 Lab 1
Nicole Wang (l.wang12@wustl.edu), Lin Li(lilin1@wustl.edu)

==================================== Lab 1 =================================================
------------ Part 1 -----------
Overview:
1. Play class:
1). Private member variables: a lock mutex, conditional_variable for orderly print out, a counter for current line being recited, a string play name, a string to keep track of current character.
2). Public Play constructor: takes in a string play name and pass it to play name member variable, initialize counter as 1, initialize current character as empty string
3). Public recite method: takes in a container iterator
	a). make a unique_lock to avoid race condition;
	b). If current counter is bigger than the order in iterator, we will print out an error message and increment iterator
	c). Otherwise, construct a conditional variable to make sure counter is equal to current order in iterator so that each line prints out in a orderly fashion. To check for empty currcharacter variable and make sure it is same as characterName for current iterator,
		If there is a change in character, print character name.
	d). Followed by current text in this iterate, increment iterator and counter.
	e). Last, after all iterations, we will release lock and notify all.
4). We also put our enumerators, packages included and container structor in this class.

2. Player class:
1). Private member variables: a shared pointer to input file stream, a const character name string, a reference to the play object, all these will be initialized in Player constructor; a thread t, a vector storing container.
2). Public Player constructor: takes in a reference to Play object, a const reference to character name, a shared pointer for input file stream indicating specific character file. Initialized first three private member variables by using initializer list.
3). Public read() method: this method is to read line by line from script file, and store each line into container and push them into a vector
	a). Using getline method to read each line
	b). if line is not empty, check the line is valid by checking line number is bigger than 0 and line is not empty.
	c). if is valid line, we will make a container and store the information of this line into it and push the container to the container vector.
4). Public act() method: to make sure each character is come in at correct order, we iterate through the vector containter and refer to play object and call the recite method on each iteration.
5). Public enter() method: we will make a new thread to call read() method and act() method in Player class. Then, transfor the ownership of this new thread to our thread member variable.
6). Public exit() method: to avoid thread infinitely running, we will check if the thread is joinable, and then join it.

3. Main function:
1). Check for right number of arguments: if argument counter is not equal to 2, we will print a usage message and return an error code.
2). Open the input configuration file using fstream, if can be opend, do steps 3 - 10 below; otherwise, print a message indicating that file not exit and reture error code.
3). Initialize a bool valid to indicate whether the extracted line is valid or not.
4). Read the file line by line and ignore all the empty line.
5). Extract the first line which is the play name and put it into the play object, and at this point, we will have a Player vector for later usage.
6). For each non-empty line, we will pass it into a istringstream and if we can extract both character name and file name successfully,:
	a). Dynamically initialize character file stream and pass it into a shared pointer.
	b). if the file is open, we set valid boolean into true, and construct a Player object with Play object, character name extracted and shared pointer of character files, and push them into Player vector.
	c). Otherwise, print out error message to indicate character file cannot be opened.
7). Otherwise, print a message to indicate badly formatted line is being captured.
8). If the boolean valid is false, we will print error message to indicate no valid character information is extracted and return an error code.
9). We will iterate through player vector, for each player object, call enter() method to calling the right player to enter the scene through a thread.
10). After all player enters, we will call exit() method for each player object and join the thread.


Wrapper Facades:
1. We use the unique_lock with a mutex synchronization abstraction.
2. Classes are cohensive:
class Play
{
public:
	Play(string n);
	void recite(vector<container>::iterator it);
};
class Player {
public:
	Player(Play& p,const string& charName, shared_ptr<ifstream> inputFile);
	void read();
	void act();
	void enter();
	void exit();

};
In our main method, we construct a Play object and pass the play name. Then, we pass the play object into a Player object.


Insights, Observations & Questions:
1. We saw some lines has a whitespace at begining of the line and we use trim() to get rid of them.
2. Use Condition Variables make sure the lines print out in the right order, so that we don't need to sort the vector before print as we did in lab0.
3. We use shared_ptr for input file stream in order to get the correct file.

------------ Part 2 -----------
Unpacking Instructions:
1. Open the downloaded and extracted Lab1_Full directory and find lab1.zip, and right click on the zip file, select: 7-zip -> Extract Here
2. Click on lab1 directory, double click on lab1.sln in the lab1 directory and open with Visual Studio 2019
3. Build the solution: select Build -> Build Solution
4. Open Terminal or CMD window, direct to lab1\x64\Debug directory and find the execution file lab1.exe and the sample files(hamlet_ii_2_config.txt)
5. Type in command as following format: lab1.exe <config_file>
Example: lab1.exe hamlet_ii_2_config.txt

------------ Part 3 -----------
Evaluation:
1. Well formed content
Command line: lab1.exe hamlet_ii_2_config.txt
where hamlet_ii_2_config.txt shows as below:
Hamlet Prince of Denmark ACT II Scene II A room in the Castle by William Shakespeare
Guildenstern Guildenstern.txt
King King.txt
Queen Queen.txt
Rosencrantz Rosencrantz.txt
Output:
King.
Welcome, dear Rosencrantz and Guildenstern!
Moreover that we much did long to see you,
The need we have to use you did provoke
Our hasty sending. Something have you heard
Of Hamlet's transformation; so I call it,
Since nor the exterior nor the inward man
Resembles that it was. What it should be,
More than his father's death, that thus hath put him
So much from the understanding of himself,
I cannot dream of: I entreat you both
That, being of so young days brought up with him,
And since so neighbour'd to his youth and humour,
That you vouchsafe your rest here in our court
Some little time: so by your companies
To draw him on to pleasures, and to gather,
So much as from occasion you may glean,
Whether aught, to us unknown, afflicts him thus,
That, open'd, lies within our remedy.

Queen.
Good gentlemen, he hath much talk'd of you,
And sure I am two men there are not living
To whom he more adheres. If it will please you
To show us so much gentry and good-will
As to expend your time with us awhile,
For the supply and profit of our hope,
Your visitation shall receive such thanks
As fits a king's remembrance.

Rosencrantz.
Both your majesties
Might, by the sovereign power you have of us,
Put your dread pleasures more into command
Than to entreaty.

Guildenstern.
We both obey,
And here give up ourselves, in the full bent,
To lay our service freely at your feet,
To be commanded.

King.
Thanks, Rosencrantz and gentle Guildenstern.

Queen.
Thanks, Guildenstern and gentle Rosencrantz:
And I beseech you instantly to visit
My too-much-changed son.--Go, some of you,
And bring these gentlemen where Hamlet is.

Guildenstern.
Heavens make our presence and our practices
Pleasant and helpful to him!

Queen.
Ay, amen!
Return code: 0 (success)

2. Badly Format configuration file without error:
Hamlet Prince of Denmark ACT II Scene II A room in the Castle by William Shakespeare
Guildenstern Guildenstern.txt
King King.txt
Queen Queen.txt
1.txt

Rosencrantz Rosencrantz.txt

1 2

  5
Observation: It will skip all the bad formatted lines
Output: same as the above output
Return code: 0 (success)

2. Badly Format configuration file with error:
Hamlet Prince of Denmark ACT II Scene II A room in the Castle by William Shakespeare
Guildenstern Guildenstern.txt
King
Queen Queen.txt
Rosencrantz Rosencrantz.txt

Observation: It will capture all the badly formatted line and non-exists character file.
Output:
badly formatted line
character file can not open
badly formatted line

King.
Welcome, dear Rosencrantz and Guildenstern!
Moreover that we much did long to see you,
The need we have to use you did provoke
Our hasty sending. Something have you heard
Of Hamlet's transformation; so I call it,
Since nor the exterior nor the inward man
Resembles that it was. What it should be,
More than his father's death, that thus hath put him
So much from the understanding of himself,
I cannot dream of: I entreat you both
That, being of so young days brought up with him,
And since so neighbour'd to his youth and humour,
That you vouchsafe your rest here in our court
Some little time: so by your companies
To draw him on to pleasures, and to gather,
So much as from occasion you may glean,
Whether aught, to us unknown, afflicts him thus,
That, open'd, lies within our remedy.

Queen.
Good gentlemen, he hath much talk'd of you,
And sure I am two men there are not living
To whom he more adheres. If it will please you
To show us so much gentry and good-will
As to expend your time with us awhile,
For the supply and profit of our hope,
Your visitation shall receive such thanks
As fits a king's remembrance.

Rosencrantz.
Both your majesties
Might, by the sovereign power you have of us,
Put your dread pleasures more into command
Than to entreaty.

Guildenstern.
We both obey,
And here give up ourselves, in the full bent,
To lay our service freely at your feet,
To be commanded.

King.
Thanks, Rosencrantz and gentle Guildenstern.

Queen.
Thanks, Guildenstern and gentle Rosencrantz:
And I beseech you instantly to visit
My too-much-changed son.--Go, some of you,
And bring these gentlemen where Hamlet is.

Guildenstern.
Heavens make our presence and our practices
Pleasant and helpful to him!

Queen.
Ay, amen!
Return code: 0 (success)


3. Bad input command lines
Command: lab1.exe hamlet_ii_2_
Output: Configure File not exists.
Return code: 3 (FileNotExist)

4. Wrong number of Arguments
Command: lab1.exe
Output: usage: lab1.exe <configuration_file_name>
Return code: 1 (inputNumberNotCorrect)


==================================== Lab 1 Extra Credit =================================================
Approach to the extra credit part:
1. Arguments: at least 4 arguments with one optional case using SCRAMBLE
1). execution file name
2). Optional case: SCRAMBLE
3). the name of a script fragment file
4). the name of a configuration file to generate
5). the name of the play: starting from 4th or 5th argument(optional case), the rest are seen as name of the play

2. Main Function: check for right number of arguments with 2 cases:
1). if argument counter is >= 5 which is the case with optional SCRAMBLE inputted and second argument is same as the string SCRAMBLE:
	a). If yes, make sure 3rd and 4th argument are different to avoid user over writes its input file.
	b). If same 3rd and 4th arguments, we will print out an error message indicating that files cannot be same and return an error code.
	c). Otherwise, enter extraCredit1() function with parameters input file, output file and concatenant play name.
2). if argument counter is >= 4 which is the case without optional SCRAMBLE inputted:
	a). If yes, make sure 2nd and 3rd argument are different to avoid user over writes its input file.
	b). If same 2nd and 3rd arguments, we will print out an error message indicating that files cannot be same and return an error code.
	c). Otherwise, enter extraCredit0() function with parameters input file, output file and concatenant play name.
3). If both 1) and 2) failed, we will print a usage message to user for correct input formats.

3. ExtraCredit0() Function:
1). Input file stream for the script fragment file
2). Output file stream for the configuration file
3). Output file streams for the part file for each character
4). Do following steps:
Steps:
5). Open 1) and 2) file streams, initialized a map to store keys, the character name(Guildenstern, King, Queen, Rosencrantz), for corresponding values, the character file name(Guildenstern.txt, King.txt, Queen.txt, and Rosencrantz.txt).If the file streams are not opened, we will print out "File cannot open" error message and return an error code fileDoesNotExist.
6). Set a boolean value changeCharacter to indicate the change of character, so we need to open the corresponding character file and append new scripts.
Idea: At the beginning, we set changeCharacter as true to read the first character infomation and scripts. As long as we have checked changeCharacter as true, we will set it to false, until it encounters a empty line, we set it back to true.
7). Storing character into map: when we encounter a character being read, we will first check if it is already existing in map. If not, insert a new character.
8). If changeCharacter is false, we will append the current line to the part file for that particular character(the characterName is stored in variable), and we will increment the ordering variable called i in our code.
9). After all lines read,
   a). If the character file is opened, we will close it.
   b). We will iterate throught the map and write the keys and values to the configuration file.
   c). We will close the script fragment file and the configuration file.
   d). Return success.

4. ExtraCredit1() Function:
1). Input file stream for the script fragment file
2). Output file stream for the configuration file
3). Output file streams for the part file for each character
4). Do following steps:
Steps:
5). Open 1) and 2) file streams, initialized a map to store keys, the character name(Guildenstern, King, Queen, Rosencrantz), for corresponding values, the vector of all lines (each line has order & text). If the file streams are not opened, we will print out "File cannot open" error message and return an error code fileDoesNotExist.
6). Set a boolean value changeCharacter to indicate the change of character, so we need to open the corresponding character file and append new scripts.
Idea: At the beginning, we set changeCharacter as true to read the first character infomation and scripts. As long as we have checked changeCharacter as true, we will set it to false, until it encounters a empty line, we set it back to true.
7). Storing character into map key: when we encounter a character being read, we will first check if it is already existing in map. If not, insert a new character amd a empty string vector.
8). If changeCharacter is false, we will push the current line to the string vector value fpr that particular character key in the map, and we will increment the ordering variable called i in our code.
9). After all lines read,
    a). create an output file stream
	b). loop through each character in the characters map:
		(1). Open this particular character file, and use random_shuffle() to shuffle the value corresponding to this character key in the map.
		(2). If this particular character file is opened, iterate through the corresponding value in the map which stores the character text,  and write each string text to the character file.
		(3). Otherwise, print out an error message to indicate character file is not open.
		(4). Close the character file
		(5). Write each character name and name with ".txt" into the output file stream for the configuration file.
	c). We will close the script fragment file and the configuration file.
	d). Return success.


Unpacking Instructions:
1. Open the downloaded and extracted Lab1_Full directory and find lab1Extra.zip, and right click on the zip file, select: 7-zip -> Extract Here
2. Click on lab1Extra directory, double click on lab0Extra.sln in the lab1Extra directory and open with Visual Studio 2019
3. Build the solution: select Build -> Build Solution
4. Open Terminal or CMD window, direct to lab1Extra\x64\Debug directory and find the execution file lab1Extra.exe and the sample files(hamlet_act_ii_scene_2.txt)
5. Type in either correct command as following format:
1). lab1Extra.exe <inputFileName> <outputFileName> <playName>
Example: lab1Extra.exe hamlet_act_ii_scene_2.txt hamlet_ii_2_config.txt Hamlet Prince of Denmark ACT II Scene II A room in the Castle by William Shakespeare
2). lab1Extra.exe SCRAMBLE <inputFileName> <outputFileName> <playName>
Example: lab1Extra.exe SCRAMBLE hamlet_act_ii_scene_2.txt hamlet_ii_2_config.txt Hamlet Prince of Denmark ACT II Scene II A room in the Castle by William Shakespeare


Document how you used it in your testing of the assignment
1. Open Terminal or CMD window, direct to lab1Extra\Debug directory and find the execution file lab1Extra.exe and the sample files(hamlet_act_ii_scene_2.txt)
2. Type in command as following two correct format:
(1). lab1Extra.exe <inputFileName> <outputFileName> <playName>
Example: lab1Extra.exe hamlet_act_ii_scene_2.txt hamlet_ii_2_config.txt Hamlet Prince of Denmark ACT II Scene II A room in the Castle by William Shakespeare
Output:
a). Files: hamlet_ii_2_config.txt, Guildenstern.txt, King.txt, Queen.txt, and Rosencrantz.txt

b). hamlet_ii_2_config.txt:
Hamlet Prince of Denmark ACT II Scene II A room in the Castle by William Shakespeare
Guildenstern Guildenstern.txt
King King.txt
Queen Queen.txt
Rosencrantz Rosencrantz.txt

c). Guildenstern.txt:
31 We both obey,
32 And here give up ourselves, in the full bent,
33 To lay our service freely at your feet,
34 To be commanded.
40 Heavens make our presence and our practices
41 Pleasant and helpful to him!

d). King.txt:
1  Welcome, dear Rosencrantz and Guildenstern!
2  Moreover that we much did long to see you,
3  The need we have to use you did provoke
4  Our hasty sending. Something have you heard
5  Of Hamlet's transformation; so I call it,
6  Since nor the exterior nor the inward man
7  Resembles that it was. What it should be,
8  More than his father's death, that thus hath put him
9  So much from the understanding of himself,
10 I cannot dream of: I entreat you both
11 That, being of so young days brought up with him,
12 And since so neighbour'd to his youth and humour,
13 That you vouchsafe your rest here in our court
14 Some little time: so by your companies
15 To draw him on to pleasures, and to gather,
16 So much as from occasion you may glean,
17 Whether aught, to us unknown, afflicts him thus,
18 That, open'd, lies within our remedy.
35 Thanks, Rosencrantz and gentle Guildenstern.

e). Queen.txt:
19 Good gentlemen, he hath much talk'd of you,
20 And sure I am two men there are not living
21 To whom he more adheres. If it will please you
22 To show us so much gentry and good-will
23 As to expend your time with us awhile,
24 For the supply and profit of our hope,
25 Your visitation shall receive such thanks
26 As fits a king's remembrance.
36 Thanks, Guildenstern and gentle Rosencrantz:
37 And I beseech you instantly to visit
38 My too-much-changed son.--Go, some of you,
39 And bring these gentlemen where Hamlet is.
42 Ay, amen!

f). Rosencrantz.txt
27 Both your majesties
28 Might, by the sovereign power you have of us,
29 Put your dread pleasures more into command
30 Than to entreaty.

(2). lab1Extra.exe SCRAMBLE <inputFileName> <outputFileName> <playName>
Example: lab1Extra.exe SCRAMBLE hamlet_act_ii_scene_2.txt hamlet_ii_2_config.txt Hamlet Prince of Denmark ACT II Scene II A room in the Castle by William Shakespeare
Output:
a). Files: hamlet_ii_2_config.txt, Guildenstern.txt, King.txt, Queen.txt, and Rosencrantz.txt

b). hamlet_ii_2_config.txt:
Hamlet Prince of Denmark ACT II Scene II A room in the Castle by William Shakespeare
Guildenstern Guildenstern.txt
King King.txt
Queen Queen.txt
Rosencrantz Rosencrantz.txt

c). Guildenstern.txt:
40 Heavens make our presence and our practices
32 And here give up ourselves, in the full bent,
34 To be commanded.
33 To lay our service freely at your feet,
31 We both obey,
41 Pleasant and helpful to him!

d). King.txt:
14 Some little time: so by your companies
8 More than his father's death, that thus hath put him
6 Since nor the exterior nor the inward man
2 Moreover that we much did long to see you,
4 Our hasty sending. Something have you heard
13 That you vouchsafe your rest here in our court
18 That, open'd, lies within our remedy.
35 Thanks, Rosencrantz and gentle Guildenstern.
1 Welcome, dear Rosencrantz and Guildenstern!
9 So much from the understanding of himself,
3 The need we have to use you did provoke
12 And since so neighbour'd to his youth and humour,
16 So much as from occasion you may glean,
7 Resembles that it was. What it should be,
5 Of Hamlet's transformation; so I call it,
15 To draw him on to pleasures, and to gather,
11 That, being of so young days brought up with him,
17 Whether aught, to us unknown, afflicts him thus,
10 I cannot dream of: I entreat you both

e). Queen.txt:
19 Good gentlemen, he hath much talk'd of you,
23 As to expend your time with us awhile,
36 Thanks, Guildenstern and gentle Rosencrantz:
20 And sure I am two men there are not living
21 To whom he more adheres. If it will please you
22 To show us so much gentry and good-will
39 And bring these gentlemen where Hamlet is.
26 As fits a king's remembrance.
24 For the supply and profit of our hope,
38 My too-much-changed son.--Go, some of you,
42 Ay, amen!
37 And I beseech you instantly to visit
25 Your visitation shall receive such thanks

f). Rosencrantz.txt
28 Might, by the sovereign power you have of us,
27 Both your majesties
29 Put your dread pleasures more into command
30 Than to entreaty.
