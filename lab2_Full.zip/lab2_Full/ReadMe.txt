How submission file was produced:
> lab2_Full\
> |- ReadMe.txt
> |- Output\
>    |- Lab2Output\
>        |- Lab2Output.txt
>    |- Lab2ExtraOutput_Part1\
>        |- hamlet_ii_1a_config.txt
>        |- hamlet_ii_1b_config.txt
>        |- Ophelia_hamlet_ii_1b.txt
>        |- partial_hamlet_act_ii_scene_1_script.txt
>        |- Polonius_hamlet_ii_1a.txt
>        |- Polonius_hamlet_ii_1b.txt
>        |- Reynaldo_hamlet_ii_1a.txt
>    |- Lab2ExtraOutput_Part2\
>        |- Lab2ExtraOutput_Part2.txt
> |- lab2.zip\
> |- lab2Extra.zip\


Unpack:
Download lab2_Full.zip, Right click on the zip file, select: 7-zip -> Extract Here
