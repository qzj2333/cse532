CSE 532 Spring 2020 Lab 0
Nicole Wang (l.wang12@wustl.edu), Lin Li(lilin1@wustl.edu)

Overview:
1. Container struct: script order, character name , script corresponding to the order

2. Play class:
1). Variables: mutex, string name for play name, vector container for single line script
2). play constructor: initialize play name
3). insert operator <<: provide lock for synchronizing, push container to vector container, return current object
4). print method: (no need to lock because print is called after all threads are joined) sort vector by script order, iterate through vector container, if character changed or not initialized, print the character name and the corresponding script; Otherwise, just print the corresponding script

3. Thread Function:
1). Variables: string line for each line read from ifstream, lineNum for the script order
2). For each extracted non-empty line(skipping all empty lines), separate line with space and pass the order to variable lineNum and the script to line
3). If lineNum and line valid, pass lineNum, character name and line into container, and then push container into play
4). Close part pointer and no need to delete part pointer since shared_ptr will delete automatically, to avoid double deletion

4. Main Function:
1). check for right number of arguments (is number of arguments = 2?)
	If no, print the usage message and return error code numberArgumentIncorrect
	Otherwise, go to step 2)
2). Open configuration file by given file name provided in second argument
3). Extract the play name from first non-empty line
4). For each non-empty line after, separate the line with space and pass first object to characteName and the second object to fname indicating the character file name
	a). Create a shared pointer of ifstream for valid character file and pass the shared pointer into thread function while making new thread in next step
	b). Make new thread for each character and character file,
	c). Emplace back each thread into thread vector
5). Use try/catch block for step 4 to avoid any possible exception during threading
5). Make safely join for each thread in the vector threads
6). Call play's print method to print the play script
7). Close configuration file
8). Return 0 to indicate success


Wrapper Facedes:
Define the print method and the insert operator <<, so that user in the main method does not need to bother the order of the line script

Insight, observations and questions:
1. Using shared_ptr to allow dynamic allocation for different character file ifstream in main function
2. No need to lock in print method because print is called after all threads are joined

Instructions:
1. Download lab0 zip file and right click on the zip file, select: 7-zip -> Extract Here
2. Click on lab0 directory, double click on lab0.sln in the lab0 directory and open with Visual Studio 2019
3. Build the solution: select Build -> Build Solution
4. Open Terminal or CMD window, direct to lab0\x64\Debug directory and find the execution file lab0.exe and the sample files(hamlet_ii_2_config.txt)
5. Type in command as following format: lab0.exe <config_file>
Example: lab0.exe hamlet_ii_2_config.txt

Evaluation:
1. Well formed content
Command line: lab0.exe hamlet_ii_2_config.txt
where hamlet_ii_2_config.txt shows as below:
Hamlet Prince of Denmark ACT II Scene II A room in the Castle by William Shakespeare
Guildenstern Guildenstern.txt
King King.txt
Queen Queen.txt
Rosencrantz Rosencrantz.txt
Output:
King.
Welcome, dear Rosencrantz and Guildenstern!
Moreover that we much did long to see you,
The need we have to use you did provoke
Our hasty sending. Something have you heard
Of Hamlet's transformation; so I call it,
Since nor the exterior nor the inward man
Resembles that it was. What it should be,
More than his father's death, that thus hath put him
So much from the understanding of himself,
I cannot dream of: I entreat you both
That, being of so young days brought up with him,
And since so neighbour'd to his youth and humour,
That you vouchsafe your rest here in our court
Some little time: so by your companies
To draw him on to pleasures, and to gather,
So much as from occasion you may glean,
Whether aught, to us unknown, afflicts him thus,
That, open'd, lies within our remedy.

Queen.
Good gentlemen, he hath much talk'd of you,
And sure I am two men there are not living
To whom he more adheres. If it will please you
To show us so much gentry and good-will
As to expend your time with us awhile,
For the supply and profit of our hope,
Your visitation shall receive such thanks
As fits a king's remembrance.

Rosencrantz.
Both your majesties
Might, by the sovereign power you have of us,
Put your dread pleasures more into command
Than to entreaty.

Guildenstern.
We both obey,
And here give up ourselves, in the full bent,
To lay our service freely at your feet,
To be commanded.

King.
Thanks, Rosencrantz and gentle Guildenstern.

Queen.
Thanks, Guildenstern and gentle Rosencrantz:
And I beseech you instantly to visit
My too-much-changed son.--Go, some of you,
And bring these gentlemen where Hamlet is.

Guildenstern.
Heavens make our presence and our practices
Pleasant and helpful to him!

Queen.
Ay, amen!
Return code: 0 (success)

2. Bad Format configuration file:
Hamlet Prince of Denmark ACT II Scene II A room in the Castle by William Shakespeare
Guildenstern Guildenstern.txt
King King.txt
Queen Queen.txt
1.txt

Rosencrantz Rosencrantz.txt

1 2

  5
Observation: It will skip all the bad formatted lines
Output: same as the above output
Return code: 0 (success)

3. Bad input command lines
Command: lab0.exe hamlet_ii_2_
Output: Configure File not exists.
Return code: 3 (FileNotExist)

4. Wrong number of Arguments
Command: lab0.exe
Output: usage: lab0.exe <configuration_file_name>
Return code: 1 (inputNumberNotCorrect)


==================Extra Credit==================
Approach to the extra credit part:
1. Arguments: at least 4 arguments
1). execution file name
2). the name of a script fragment file
3). the name of a configuration file to generate
4). the name of the play: starting from 4th argument, the rest are seen as name of the play

2. Main Function: check for right number of arguments (is number of arguments >= 4?)
1).	If yes, enter extraCredit() function
2).	If no, print the usage message and return error code numberArgumentIncorrect

3. ExtraCredit Function:
1). Input file stream for the script fragment file
2). Output file stream for the configuration file
3). Output file streams for the part file for each character

Steps:
1. Open 1) and 2) file streams, initialized a map to store keys, the character name(Guildenstern, King, Queen, Rosencrantz), for corresponding values, the character file name(Guildenstern.txt, King.txt, Queen.txt, and Rosencrantz.txt).If the file streams are not opened, we will print out "File cannot open" error message and return an error code fileDoesNotExist.

2. Set a boolean value changeCharacter to indicate the change of character, so we need to open the corresponding character file and append new scripts.
Idea: At the beginning, we set changeCharacter as true to read the first character infomation and scripts. As long as we have checked changeCharacter as true, we will set it to false, until it encounters a empty line, we set it back to true.

3. Stroing character into map: when we encounter a character being read, we will first check if it is already existing in map. If not, insert a new character.

4. If changeCharacter is false, we will append the current line to the part file for that particular character(the characterName is stored in variable), and we will increment the ordering variable called i in our code.

5. After all lines read,
1). If the character file is opened, we will close it.
2). We will iterate throught the map and write the keys and values to the configuration file.
3).	We will close the script fragment file and the configuration file.



Give instructions for how to unpack, build, and use it:
1. Download lab0Extra zip file and right click on the zip file, select: 7-zip -> Extract Here
2. Click on lab0Extra directory, double click on lab0Extra.sln in the lab0Extra directory and open with Visual Studio 2019
3. Build the solution: select Build -> Build Solution
4. Open Terminal or CMD window, direct to Debug directory and find the execution file lab0Extra.exe and the sample files(hamlet_act_ii_scene_2.txt)
5. Type in command as following format: lab0Extra.exe <inputFileName> <outputFileName> <playName>
Example: lab0Extra.exe hamlet_act_ii_scene_2.txt hamlet_ii_2_config.txt Hamlet Prince of Denmark ACT II Scene II A room in the Castle by William Shakespeare



Document how you used it in your testing of the assignment
1. Open Terminal or CMD window, direct to lab0Extra\x64\Debug directory and find the execution file lab0Extra.exe and the sample files(hamlet_act_ii_scene_2.txt)
2. Type in command as following format: lab0Extra.exe <inputFileName> <outputFileName> <playName>
Example: lab0Extra.exe hamlet_act_ii_scene_2.txt hamlet_ii_2_config.txt Hamlet Prince of Denmark ACT II Scene II A room in the Castle by William Shakespeare
3. Output:
1). Files: hamlet_ii_2_config.txt, Guildenstern.txt, King.txt, Queen.txt, and Rosencrantz.txt

2). hamlet_ii_2_config.txt:
Hamlet Prince of Denmark ACT II Scene II A room in the Castle by William Shakespeare
Guildenstern Guildenstern.txt
King King.txt
Queen Queen.txt
Rosencrantz Rosencrantz.txt

3). Guildenstern.txt:
31 We both obey,
32 And here give up ourselves, in the full bent,
33 To lay our service freely at your feet,
34 To be commanded.
40 Heavens make our presence and our practices
41 Pleasant and helpful to him!

4). King.txt:
1  Welcome, dear Rosencrantz and Guildenstern!
2  Moreover that we much did long to see you,
3  The need we have to use you did provoke
4  Our hasty sending. Something have you heard
5  Of Hamlet's transformation; so I call it,
6  Since nor the exterior nor the inward man
7  Resembles that it was. What it should be,
8  More than his father's death, that thus hath put him
9  So much from the understanding of himself,
10 I cannot dream of: I entreat you both
11 That, being of so young days brought up with him,
12 And since so neighbour'd to his youth and humour,
13 That you vouchsafe your rest here in our court
14 Some little time: so by your companies
15 To draw him on to pleasures, and to gather,
16 So much as from occasion you may glean,
17 Whether aught, to us unknown, afflicts him thus,
18 That, open'd, lies within our remedy.
35 Thanks, Rosencrantz and gentle Guildenstern.

5). Queen.txt:
19 Good gentlemen, he hath much talk'd of you,
20 And sure I am two men there are not living
21 To whom he more adheres. If it will please you
22 To show us so much gentry and good-will
23 As to expend your time with us awhile,
24 For the supply and profit of our hope,
25 Your visitation shall receive such thanks
26 As fits a king's remembrance.
36 Thanks, Guildenstern and gentle Rosencrantz:
37 And I beseech you instantly to visit
38 My too-much-changed son.--Go, some of you,
39 And bring these gentlemen where Hamlet is.
42 Ay, amen!

6). Rosencrantz.txt
27 Both your majesties
28 Might, by the sovereign power you have of us,
29 Put your dread pleasures more into command
30 Than to entreaty.
