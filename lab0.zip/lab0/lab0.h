#if ! defined (LAB0_H)
#define LAB0_H

#pragma once
#include <iostream>
#include <thread>
#include <fstream>
#include <string>
#include <vector>
#include <algorithm>
#include <mutex>
#include <memory>

using namespace std;

enum returnValues
{
	success = 0,
	inputNumberNotCorrect = 1,
	threadingError = 2,
	FileNotExist = 3
};

enum arg
{
	programName = 0,
	configureFile = 1,
	rightNumberArgument = 2
};

struct container
{
	unsigned int order;
	string characterName;
	string text;

	bool operator<(const container& c);
};

class play
{
private:
	mutex m;
	string name;
	vector<container> content;
public:
	play(string n);
	play* operator<<(container c);
	void print(ostream& o);
};

#endif /* defined LAB0_H */

