#include "lab0.h"

bool container::operator<(const container& c)
{
	return order < c.order;
}

play::play(string n)
{
	name = n;
};

play* play::operator<<(container c)
{
	lock_guard<mutex> guard(m);
	content.push_back(c);
	return this;
}

void play::print(ostream& o)
{
	//lock_guard<mutex> guard(m);	// no need to lock because print is called after all threads are joined
	sort(content.begin(), content.end());
	string currCharacter;
	for (container c : content)
	{
		if (currCharacter == "" || currCharacter.compare(c.characterName) != 0) // if change character or beginning of the play
		{
			currCharacter = c.characterName;
			o << "\n" << c.characterName << "." << endl;
		}
		o << c.text << endl;
	}
}

void func(play& p, const string& name, shared_ptr<ifstream> part)
{
	string line;
	size_t pos;
	unsigned int lineNum;

		while (getline(*part.get(), line))
		{
			if (!line.empty())	// skip empty line
			{
				pos = line.find(' ', 0);
				lineNum = stoi(line.substr(0, pos)); // convert string to int
				line = line.substr(pos + 1);
				if (lineNum > 0 && !line.empty()) // lineNum valid > 0
				{
					container c;
					c.order = lineNum;
					c.characterName = name;
					c.text = line;
					p << c;
				}
			}
	}
	part.get()->close();
	// no need to delete part pointer since shared_ptr will delete automatically
}

int main(int argc, char** argv)
{
	if (argc != rightNumberArgument)
	{
		cout << "usage: " << argv[programName] << " <configuration_file_name>" << endl;
		return inputNumberNotCorrect;
	}
	fstream configFile;
	configFile.open(argv[configureFile]);
	if (configFile.is_open())
	{
		string line;
		// get first non-blank line as play name
		while (getline(configFile,line) && line.empty())
		{
			continue;
		}
		string playName = line;
		play p(playName);
		vector<thread> threads;
		try
		{
			while (getline(configFile, line))
			{
				if (!line.empty())
				{
					size_t pos = line.find(' ', 0);
					string cName = line.substr(0, pos);
					string fName = line.substr(pos + 1);
					ifstream* characterFile = new ifstream(fName);
					// dynamic allocation for different character file ifstream
					shared_ptr<ifstream> ptr(characterFile);
					if (ptr->is_open())
					{
						threads.emplace_back(thread(func, ref(p), cName, ptr));
					}
				}
			}
		}
		catch (...)
		{
			cerr << "Error occured during threading" << endl;
			return threadingError;
		}

		for (thread &t : threads)
		{
			if (t.joinable()) 
			{
				t.join();
			}
			
		}
		p.print(cout);
	}
	else 
	{
		cout << "Configure File not exists." << endl;
		return FileNotExist;
	}
	configFile.close();
	return success;
}